"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)
    no_of_items_in_texts = len(texts)
    #since the texts have a sending no and receiving no per item in the list
    #we then multiply each item by 2 to get the total record of phones in the texts record
    total_records_texts = no_of_items_in_texts * 2
    

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    no_of_items_in_calls = len(calls)
    #since the calls have a calling no and receiving no per item in the list
    #we then multiply each item by 2 to get the total record of phones in the calls record
    total_records_calls = no_of_items_in_calls * 2
    
    #total records of phones is the addition of the phones records of texts and calls
    total_telephone_numbers = total_records_texts + total_records_calls
    print("There are {} different telephone numbers in the records.".format(total_telephone_numbers))


"""
TASK 1:
How many different telephone numbers are there in the records? 
Print a message:
"There are <count> different telephone numbers in the records."
"""
