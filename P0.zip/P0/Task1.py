"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
#initializing the unique texts no. to 0 
unique_texts_num = 0
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)
    sender_texts_num = set()
    receiver_text_num = set()
    for text in texts:
        sender_texts_num.add(text[0])  
        receiver_text_num.add(text[1])
    unique_texts_num = sender_texts_num.union(receiver_text_num)

#initializing the unique calls no. to 0    
unique_calls_num = 0
with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    sender_calls_num = set()
    receiver_call_num = set()
    for call in calls:
        sender_calls_num.add(call[0])  
        receiver_call_num.add(call[1])
    unique_calls_num = sender_calls_num.union(receiver_call_num)
    
#total records of phones is the addition of the phones records of texts and calls
total_unique_telephone_numbers = unique_calls_num.union(unique_texts_num)

print("There are {} different telephone numbers in the records.".format(len(total_unique_telephone_numbers)))


"""
TASK 1:
How many different telephone numbers are there in the records? 
Print a message:
"There are <count> different telephone numbers in the records."
"""
