"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)
    sender_texts = set()
    non_tele_text = set()
    for text in texts:
        sender_texts.add(text[0])  
        non_tele_text.add(text[1])
    tele_texts = sender_texts.difference(non_tele_text)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    #creating an empty set noting that sets do not allow for duplicates
    sender_calls = set()
    non_tele_call = set()
    for call in calls:
        sender_calls.add(call[0])  
        non_tele_call.add(call[1])
    tele_calls = sender_calls.difference(non_tele_call)
    final_tele_calls = tele_calls.difference(tele_texts)
    print("These numbers could be telemarketers: ")
    #converting the set to list because set cannot be sorted
    new_tele_list = list(final_tele_calls)
    #sorting the list lexicologically
    new_tele_list.sort()
    
    for items in new_tele_list:
      
      print(items)

      
            
    

"""
TASK 4:
The telephone company want to identify numbers that might be doing
telephone marketing. Create a set of possible telemarketers:
these are numbers that make outgoing calls but never send texts,
receive texts or receive incoming calls.


Print a message:
"These numbers could be telemarketers: "
<list of numbers>
The list of numbers should be print out one per line in lexicographic order with no duplicates.
"""

