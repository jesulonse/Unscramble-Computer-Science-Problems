"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    #initially the longest call time to be equal to zero and sender number to an empty string
    longest_call = 0
    sender_number = ""
    #iterating through the list using index i
    for i in calls:
        #checking the fourth element(index=3) of each of the list to be greater than longest_call
        if int(i[3]) > longest_call:
            #it will continue to iterate until the longest time is gotten
            longest_call = int(i[3])
            #the sender no is the first element(index=0) of each of the list
            sender_number = i[0]
            
    
    print("{} spent the longest time, {} seconds, on the phone during September 2016.".format(sender_number,longest_call))


"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""

